# 06 — Flows Summary

The full flowmap is at `reference/flowmap.html` — open it in a browser for the visual diagrams. This doc summarizes each of the 14 flows in text form so Claude Code can reference them quickly without rendering HTML.

For any flow, the visual is the source of truth. If this summary disagrees with the flowmap, the flowmap wins.

---

## I. Site Map

The dashboard is the persistent home. All other surfaces (Hall Detail, Agent Profile, Task Detail, DM, Council Chamber, Oracle) are 1–2 clicks deep. Wizards and modals overlay the dashboard.

Sidebar nav surfaces (left side): Halls, Agents, Models, Settings.

---

## II. First Launch

Six steps in 90 seconds:

1. **Welcome** — "Step into the halls"
2. **Sign in to Claude Code** — uses Claude Code's existing OAuth (the only required step)
3. **Default model tier** — Sonnet (with explanation that user can change per-agent later)
4. **Theme** — Hollow (default)
5. **Tour** — 5-hotspot guided overlay (skippable)
6. **Dashboard** — populated with 3 default halls + 6 default agents

Sign-in is the only blocker. Everything else has a working default.

---

## III. The Oracle (⌘K)

Routing classifier. User types intent → Haiku subprocess returns ranked halls + suggested agent + confidence + (optionally) clarification question.

If confidence < 0.4, Oracle asks one clarifying question instead of routing.

User can override by prefixing input with `/code`, `/design`, `/research`, etc. — bypasses Oracle.

---

## IV. In-Hall Conversation

Once a task is in a hall, agents talk amongst themselves via `[NEXT: name]` and `[DONE]` tokens. The orchestrator reads tokens, routes accordingly.

**Hop cap:** 8 hops. When hit, the orchestrator injects a system message into the current speaker telling them to deliver a **conclusion** (decided / open / suggested next steps). Never a hard failure — the user always gets something usable to iterate from.

**Bad handoff:** `[NEXT: Ghost]` (unknown agent) → yellow inline warning, routes to user with options to retry / accept / edit.

---

## V. Council Chamber

Cross-hall meetings of **Heads of Department only** (one per hall, marked with ◆ ornament).

- Heads default to **Opus latest** with **maximum extended thinking**
- A separate **Moderator subprocess** (Haiku) picks who speaks next via `[SPEAK: name]`
- Speakers may append `[SUGGEST: name]` to their replies; moderator weighs this as advisory
- End conditions: `[CLOSE]` from moderator, max 12 turns, 200K cumulative tokens, 5 min wall, user stop
- On end, moderator emits a synthesis (decisions + open points) presented to the user

**Stuck council:** if moderator picks same speaker 3× in a row, system inserts a diversity nudge. Still stuck after that → user prompted to break the deadlock.

---

## VI. Plan / Build / Review modes

Three modes, set per task, switchable mid-flight (kills + respawns subprocess with new tool allowlist; conversation history preserved via `--resume`).

| Mode | Tools | Default |
|---|---|---|
| **Plan** | Read, Grep, Glob, WebSearch (no writes) | ✓ |
| **Build** | All tools the agent is configured for | |
| **Review** | Read, Grep, Glob, Bash(read-only) | |

Mode default is Plan for new tasks. User explicitly bumps to Build (prevents accidental writes from one-shot prompts).

---

## VII. Hall Lifecycle

Five states with visible cues (border color, dot color, pulse rate, corner badge):

| State | Visual cue |
|---|---|
| **idle** | Muted border, gray dot |
| **active** | Soul-color border, pulsing dot |
| **in_meeting** | Cyan ring overlay, faster pulse |
| **waiting** | Amber dot, "?" corner badge |
| **locked** | Red border, grayscale, error CTA |

Locked halls show an inline CTA: "Budget exceeded → Adjust" or "API key invalid → Settings". One-click resolution.

---

## VIII. Agent State Machine

Eight states, transitions visible via status dot color and typing indicator:

```
offline → idle → thinking → speaking → done
                    ↓ ↑          ↓
                tool_use → waiting → (resume)
                    ↓
                  error
```

- **thinking:** API in flight, before first token. Status dot amber.
- **speaking:** During streaming. Status dot soul-colored.
- **tool_use:** Tool is executing. Tool icon overlay on avatar.
- **waiting:** Tool resolving (could take seconds-minutes). Cancellable.
- **done:** Task complete. Resets to idle after a delay.
- **error:** Failed. Surfaces error UI; recoverable returns to idle.

---

## IX. Task Lifecycle

Persistent across sessions. Tasks survive window close, machine restart.

```
draft → queued → running → paused → reviewing → completed
                              ↓                       ↑
                            failed → cancelled
```

Failed tasks keep their full transcript + tool calls. User can inspect, fix the underlying issue, click "retry from failure point".

---

## X. Hall Creation Wizard

Five steps + a sub-flow on Step 4:

1. **Identity** — name, tagline (required)
2. **Soul Color** — pick from palette (drives borders, glow, accents)
3. **Template** — Code / Design / Research / Custom (sets default tools, default agents pattern)
4. **Skills** — four paths:
   - **A · AI-Assisted** (recommended) — Oracle interviews user, generates skill.md
   - **B · Template** — markdown editor with scaffold based on Step 3
   - **C · Upload** — file drop, paste, or GitHub URL
   - **D · Prompt-as-Skill** (fallback) — plain prompt wrapped as skill
5. **Roster** — pick existing agents, create new (→ Agent Wizard), or skip. **First agent added is auto-marked as Head ◆.**

All paths produce a `skill.md` file at `.hollow-halls/halls/<slug>/skill.md`.

---

## XI. Agent Creation Wizard

Seven steps with live character preview:

1. **Name** (unique within hall, 2–20 chars)
2. **Role** (free-text, one line)
3. **Character** — six slots (body, clothing, head, eyes, accessory, tool). Live SVG preview.
4. **Home Hall** — existing or new
5. **Tools** — allowlist with dangerous tools marked red icons
6. **Prompt** — multiline editor for role overlay (appended to hall's skill)
7. **Model Tier** — Opus / Sonnet / Haiku, auto-resolves to latest in tier

**Tool risk:** No nag dialogs during selection. ONE consolidated confirmation card at the end listing all dangerous tools selected, with one "I understand" checkbox to unlock [Forge Agent].

---

## XII. Settings

Six sections:

1. **API & Keys** — view current Claude Code auth status; clear it (with typed confirmation)
2. **Models & Routing** — view + override default tier per agent class; Oracle and Moderator locked to Haiku
3. **Token Budget & Caching** — Auto / Custom / Unlimited modes; per-tier daily caps; prompt caching toggle (default ON); cost ledger viewer (cached vs fresh split)
4. **Theme & Appearance** — Hollow (default), future themes
5. **Keyboard** — remap shortcuts, vim mode toggle, quick reference
6. **Telemetry & Privacy** — all opt-in (off by default); export task history; wipe data (typed confirmation)

Destructive actions require typed confirmation (e.g. type "CLEAR KEY"). Every section has a "reset to defaults" button.

---

## XIII. Error & Edge States

Eight known failure modes with defined recovery:

| Mode | Recovery |
|---|---|
| **Missing API Key** | Banner with [Open Settings → API] CTA |
| **Rate Limit Hit** | Auto-retry with exponential backoff; queue display |
| **Network Down** | Status bar "offline"; tasks resume when back |
| **Agent Crash** | Task → FAILED with stack trace; [Retry] [Edit prompt] |
| **Bad Handoff** | Yellow warning inline; user picks retry / accept / edit |
| **Hop Cap Hit** | Current speaker delivers conclusion; [Iterate] [Bump cap] |
| **Token Budget Hit** | Halls → LOCKED; [Bump cap] [Reset window] |
| **Stuck Council** | Diversity nudge; if still stuck, user prompted |

**Core principle:** an error never blocks more than the affected task. Other halls keep working. The user always knows what broke and has at least one one-click recovery path.

---

## XIV. Keyboard & Power Use

### Global
| Shortcut | Action |
|---|---|
| `⌘K` | Open Oracle |
| `⌘/` | Command palette |
| `⌘,` | Settings |
| `⌘B` | Toggle sidebar |
| `⌘⇧A` | Quick agent launcher |
| `⌘⌥.` | Stop active task |
| `Esc` | Close modal / blur input |

### Hall switching
| Shortcut | Action |
|---|---|
| `1`–`6` | Jump to hall by number |
| `⌘→` / `⌘←` | Next / prev hall |
| `⌘↑` | Back to dashboard |

### Chat input
| Shortcut | Action |
|---|---|
| `⌘↵` | Send message |
| `⇧↵` | Newline |
| `@` | Mention agent (autocomplete) |
| `↑` | Edit last message |

### Slash commands
| Command | Effect |
|---|---|
| `/code`, `/design`, `/research` | Force route to specific hall (bypass Oracle) |
| `/plan`, `/build`, `/review` | Force task mode |
| `/council [topic]` | Start council with pre-filled topic |
| `/clear` | Clear chat scroll only (transcript preserved) |
| `/cost` | Show task cost inline |

Slash commands compose: `/build /code refactor X` sets mode and hall in one go.

---

## End-to-end power user flow

```
⌘K → "fix the auth bug" → Oracle routes to Dev Hall →
Aldric handles → [DONE] → user reviews

Three keystrokes, zero clicks.
```

This is the bar for v1 polish. Every interaction should feel that crisp.
