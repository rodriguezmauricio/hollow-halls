# 01 — Vision

## The problem

A modern developer using Claude Code can already work miracles. But the experience flattens everything into one terminal-shaped conversation. You can't see what's happening. You can't direct different "people" at different parts of the problem. There's no spatial sense of who you're talking to, what their specialty is, or how a multi-step task is progressing.

For someone working on a complex project — say, designing a new feature that needs UX, frontend, backend, and marketing input — the flat terminal model breaks down. You lose context. You forget what you asked the "designer" persona last time. You can't easily run two specialists in parallel.

## The thesis

Multi-agent AI work needs a **spatial UI**. People naturally organize collaborators by role and place. We want the same affordance for AI: an "office" where each "room" has a discipline, each "room" has characters with specialties, and you can walk between rooms or convene them in a meeting room.

The thesis isn't that one AI personality is insufficient — it clearly isn't. The thesis is that **the UI of a single rolling chat is the wrong shape** for multi-agent work. We need rooms. We need characters. We need a council chamber.

## What we're building

**Hollow Halls** is a VS Code extension that gives developers a game-inspired workspace for orchestrating multiple Claude Code agents. It looks like the inside of a small AI office:

- A **Halls Dashboard** showing all your halls as cards on a wall
- Each **Hall** is a themed discipline (Design, Development, Research, Marketing, UI/UX, Cyber-Sec, or any custom hall the user creates)
- Each hall is populated by **Agents** — characters with names, illustrated SVG portraits, and specialties
- One agent per hall is the **Head of Department** (◆ ornament), uses the most powerful model with maximum thinking, and represents the hall in council meetings
- An **Oracle** at the entrance routes ambiguous requests to the right hall
- A **Council Chamber** convenes Heads of Department for cross-discipline decisions, with a Haiku moderator picking turn order

Aesthetically: gothic vector art borrowed from Hollow Knight. Soul-colored borders per discipline. Cinzel typography. Hand-illustrated character portraits.

Architecturally: the extension does not call Anthropic's API directly. It spawns `claude` CLI subprocesses and routes their conversations. This means a Claude Max subscriber can use Hollow Halls without paying a single API token.

## Why this matters

### For the user

- **Spatial recognition reduces cognitive load.** "Aldric is in the Development hall" is more memorable than "the agent at index 3 in my prompt history."
- **Multi-agent runs are observable.** You can watch agents pass tokens between each other like watching a relay race.
- **Specialization is visible.** A user knows immediately which agent to address by walking to the right hall.
- **Council meetings produce real synthesis.** Heads of Department debating a question across disciplines produces output a single agent cannot.

### For the ecosystem

- **It demonstrates that orchestration on top of Claude Code is viable.** Most multi-agent tools today try to reinvent the model API; Hollow Halls inherits Claude Code's auth, caching, tools, MCP, and skill system for free.
- **It's a public reference implementation** of how to build a polished UI on top of a CLI agent. Anyone can fork it.
- **It's a testbed for the agent persona pattern** — does giving an AI a name, a character, and a role actually produce different/better output than a vanilla prompt? We'll find out.

## What we're not building

- A new model. We use Claude.
- A new IDE. We extend VS Code.
- A new payment system. The product is free.
- A new auth system. We use Claude Code's existing OAuth.
- A new tool ecosystem. We use Claude Code's tools and MCP.

The product is, narrowly, an **orchestration UI**. Everything else is borrowed.

## Constraints

- **Solo project.** Mauricio is a student building this between classes. The architecture must be tractable for one person.
- **No subscription billing for ourselves.** Users bring their own Claude Max subscription or API key.
- **Free forever.** This is a portfolio piece + community thing, not a startup.
- **Latest models always.** Smart defaults per role: Opus for Heads, Sonnet for general agents, Haiku for routing/moderation. Auto-bump when Anthropic ships a new model.

## Success criteria for v1

The first usable version ships when:

1. The extension can be installed from the marketplace
2. A user can sign in with their Claude Max subscription
3. The default 3 halls and 6 agents are visible and usable
4. A single agent in a hall can complete a task end-to-end
5. Two agents in a hall can pass `[NEXT:]` tokens and converge to `[DONE]`
6. The Council Chamber works with at least 3 Heads
7. Hall creation wizard works (all 4 skill paths)
8. Agent creation wizard works
9. The visual aesthetic matches the mockup (`reference/ui-mockup.html`) at production fidelity

That's v1. Everything else is post-launch.

## What v2 might look like

(Not committed. Listed only so we don't accidentally box ourselves in during v1.)

- Multi-provider support (OpenAI, Gemini, DeepSeek, local via Ollama) — Architecture C
- Public hall library on GitHub (browseable from inside the extension)
- More themes beyond the default Hollow Knight aesthetic (ditherpunk, cyberpunk neon)
- Mobile companion app for monitoring long-running tasks
- Recordings / replays of council meetings

We design v1 with these in mind but ship without them.

## North star

A user opens VS Code, sees the Hollow Halls dashboard, types `⌘K` to summon the Oracle, says "I want to ship a new pricing page", and watches as Maya in the Design Hall pulls in Aldric from the Development Hall, then convenes a quick Council with Solis from Marketing — and ships a working pricing page in 20 minutes. All on their existing Claude Max subscription. All visible. All organized.

That's the picture we're trying to draw.
