# 05 — Data Model

Source of truth for type definitions, schema, and protocol tokens.

---

## Top-level types

```ts
// src/shared/types.ts

export type Hall = {
  id: string                  // uuid
  name: string                // e.g. "Development"
  slug: string                // e.g. "dev"
  tagline: string             // one-line purpose
  soulColor: string           // hex
  templateBase: TemplateKey   // pattern selected at creation
  skillPath: string           // path to .hollow-halls/halls/<slug>/skill.md
  scenePath?: string          // path to room scene SVG
  createdAt: string           // ISO timestamp
  state: HallState
}

export type HallState =
  | 'idle'        // no active tasks
  | 'active'      // 1+ tasks running
  | 'in_meeting'  // hall is participating in a council
  | 'waiting'     // user input needed
  | 'locked'      // budget / key / network failure

export type TemplateKey = 'code' | 'design' | 'research' | 'custom'

export type Agent = {
  id: string
  hallId: string
  name: string                 // unique within hall
  role: string                 // free-text role description
  modelTier: ModelTier
  pinnedModel?: string         // optional: locked specific model string
  toolAllowlist: string[]      // tool ids this agent can use
  characterConfig: CharacterConfig
  rolePromptPath: string       // path to .hollow-halls/halls/<slug>/agents/<name>.md
  isHead: boolean              // ◆ Head of Department designation
  createdAt: string
  state: AgentState
}

export type ModelTier = 'opus' | 'sonnet' | 'haiku'

export type AgentState =
  | 'offline'     // not loaded
  | 'idle'        // awaiting input
  | 'thinking'    // api in flight, before first token
  | 'speaking'    // streaming reply
  | 'tool_use'    // executing tool
  | 'waiting'     // tool resolving
  | 'done'        // task complete
  | 'error'       // failed

export type Task = {
  id: string
  hallId: string
  startingAgentId: string
  mode: TaskMode
  status: TaskStatus
  hopCount: number
  startedAt: string
  endedAt?: string
  transcriptPath: string       // path to .hollow-halls/transcripts/<task-id>.jsonl
  totalInputTokens: number
  totalOutputTokens: number
  totalCachedTokens: number
}

export type TaskMode = 'plan' | 'build' | 'review'

export type TaskStatus =
  | 'draft'       // composer open, not yet sent
  | 'queued'      // waiting for slot
  | 'running'     // agents working
  | 'paused'      // user-input wait OR manual stop
  | 'reviewing'   // awaiting approval
  | 'completed'   // archived
  | 'failed'      // unrecoverable
  | 'cancelled'   // user terminated

export type Council = {
  id: string
  topic: string
  participatingHallIds: string[]
  status: CouncilStatus
  turnCount: number
  startedAt: string
  endedAt?: string
  transcriptPath: string
  conclusion?: string          // moderator's final synthesis
}

export type CouncilStatus =
  | 'queued'
  | 'running'
  | 'concluded'
  | 'aborted'

export type CharacterConfig = {
  body: string
  clothing?: string
  head: string
  eyes: string
  accessory?: string
  tool?: string
  cloakColor: string           // hex
}

export type Settings = {
  apiKeyPath?: string          // never the key itself; OS keychain reference
  defaultModelTiers: { opus: string; sonnet: string; haiku: string }
  budgets: Budgets
  theme: ThemeKey
  keybindings: Record<string, string>
  promptCachingEnabled: boolean
  telemetryEnabled: boolean    // always false by default
}

export type Budgets = {
  mode: 'auto' | 'custom' | 'unlimited'
  perTaskTokens: { opus: number; sonnet: number; haiku: number }
  dailyTokens: number
  warnAtPercent: number        // alert threshold, e.g. 80
}

export type ThemeKey = 'hollow' | 'ditherpunk' | 'cyberpunk'
```

---

## SQLite schema

```sql
-- 001_init.sql

CREATE TABLE halls (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  tagline TEXT NOT NULL,
  soul_color TEXT NOT NULL,
  template_base TEXT NOT NULL,
  skill_path TEXT NOT NULL,
  scene_path TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  state TEXT NOT NULL DEFAULT 'idle'
);

CREATE TABLE agents (
  id TEXT PRIMARY KEY,
  hall_id TEXT NOT NULL REFERENCES halls(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  model_tier TEXT NOT NULL,
  pinned_model TEXT,
  tool_allowlist TEXT NOT NULL,    -- JSON array
  character_config TEXT NOT NULL,  -- JSON object
  role_prompt_path TEXT NOT NULL,
  is_head INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  state TEXT NOT NULL DEFAULT 'offline',
  UNIQUE(hall_id, name)
);

CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  hall_id TEXT NOT NULL REFERENCES halls(id),
  starting_agent_id TEXT NOT NULL REFERENCES agents(id),
  mode TEXT NOT NULL DEFAULT 'plan',
  status TEXT NOT NULL DEFAULT 'draft',
  hop_count INTEGER NOT NULL DEFAULT 0,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  ended_at TEXT,
  transcript_path TEXT NOT NULL,
  total_input_tokens INTEGER NOT NULL DEFAULT 0,
  total_output_tokens INTEGER NOT NULL DEFAULT 0,
  total_cached_tokens INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE councils (
  id TEXT PRIMARY KEY,
  topic TEXT NOT NULL,
  participating_hall_ids TEXT NOT NULL,  -- JSON array
  status TEXT NOT NULL DEFAULT 'queued',
  turn_count INTEGER NOT NULL DEFAULT 0,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  ended_at TEXT,
  transcript_path TEXT NOT NULL,
  conclusion TEXT
);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL  -- JSON-encoded
);

CREATE INDEX idx_agents_hall ON agents(hall_id);
CREATE INDEX idx_tasks_hall ON tasks(hall_id);
CREATE INDEX idx_tasks_status ON tasks(status);
```

---

## Transcript JSONL format

Each task and council writes to its own JSONL file. One event per line:

```jsonl
{"ts":"2026-04-26T18:00:00Z","type":"user_message","content":"refactor my auth flow"}
{"ts":"2026-04-26T18:00:01Z","type":"agent_start","agentId":"agt_aldric","sessionId":"cl_abc"}
{"ts":"2026-04-26T18:00:02Z","type":"agent_text_delta","agentId":"agt_aldric","delta":"I'll restruct"}
{"ts":"2026-04-26T18:00:02Z","type":"agent_text_delta","agentId":"agt_aldric","delta":"ure the auth..."}
{"ts":"2026-04-26T18:00:05Z","type":"agent_tool_use","agentId":"agt_aldric","tool":"Read","input":{"path":"auth.ts"}}
{"ts":"2026-04-26T18:00:06Z","type":"agent_tool_result","agentId":"agt_aldric","result":"..."}
{"ts":"2026-04-26T18:00:10Z","type":"agent_done","agentId":"agt_aldric","tokens":{"input":1240,"output":380,"cached":1100}}
{"ts":"2026-04-26T18:00:10Z","type":"protocol_token","kind":"NEXT","target":"Mire"}
{"ts":"2026-04-26T18:00:11Z","type":"agent_start","agentId":"agt_mire","sessionId":"cl_def"}
{"ts":"2026-04-26T18:00:14Z","type":"agent_text_delta","agentId":"agt_mire","delta":"Two issues..."}
{"ts":"2026-04-26T18:00:18Z","type":"agent_done","agentId":"agt_mire","tokens":{"input":1380,"output":210,"cached":1100}}
{"ts":"2026-04-26T18:00:18Z","type":"protocol_token","kind":"DONE"}
{"ts":"2026-04-26T18:00:18Z","type":"task_complete","status":"completed"}
```

Event types (formal):

```ts
export type TranscriptEvent =
  | { ts: string; type: 'user_message'; content: string }
  | { ts: string; type: 'agent_start'; agentId: string; sessionId: string }
  | { ts: string; type: 'agent_text_delta'; agentId: string; delta: string }
  | { ts: string; type: 'agent_tool_use'; agentId: string; tool: string; input: unknown }
  | { ts: string; type: 'agent_tool_result'; agentId: string; result: unknown }
  | { ts: string; type: 'agent_done'; agentId: string; tokens: TokenCount }
  | { ts: string; type: 'protocol_token'; kind: ProtocolKind; target?: string }
  | { ts: string; type: 'task_complete'; status: TaskStatus }
  | { ts: string; type: 'error'; agentId?: string; message: string; recoverable: boolean }

export type TokenCount = { input: number; output: number; cached: number }
export type ProtocolKind = 'NEXT' | 'DONE' | 'SUGGEST' | 'SPEAK' | 'CLOSE'
```

---

## Message protocol — formal grammar

Tokens are parsed at the **trailing edge** of an agent's reply. The orchestrator scans the last ~200 characters of each completed message for the patterns below.

### Grammar

```
TOKEN       := '[' KIND ':' WS? NAME ']' | '[' BARE_KIND ']'
KIND        := 'NEXT' | 'SUGGEST' | 'SPEAK'
BARE_KIND   := 'DONE' | 'CLOSE'
NAME        := ALPHA (ALPHA | DIGIT | '_' | '-')*
ALPHA       := 'a'..'z' | 'A'..'Z'
DIGIT       := '0'..'9'
WS          := ' ' | '\t'
```

### Examples

Valid:
- `[NEXT: Mire]`
- `[NEXT:Mire]` (no space — also valid)
- `[DONE]`
- `[SUGGEST: Maya]`
- `[CLOSE]`
- `[SPEAK: Aldric]`

Invalid (will be ignored or trigger bad-handoff error):
- `[NEXT: Some Person]` — name has space
- `[NEXT: aldric, mire]` — multiple names not supported
- `[next: Aldric]` — lowercase kind

### Parser implementation outline

```ts
// src/orchestrator/protocol.ts

const TOKEN_REGEX = /\[(NEXT|SUGGEST|SPEAK):\s*([a-zA-Z][a-zA-Z0-9_-]*)\]|\[(DONE|CLOSE)\]/g

export type ParsedReply = {
  content: string         // reply with tokens stripped
  tokens: ProtocolToken[] // tokens found, in order
}

export type ProtocolToken =
  | { kind: 'NEXT' | 'SUGGEST' | 'SPEAK'; target: string }
  | { kind: 'DONE' | 'CLOSE' }

export function parseReply(raw: string): ParsedReply {
  const tokens: ProtocolToken[] = []
  const content = raw.replace(TOKEN_REGEX, (_, kindWithTarget, target, bareKind) => {
    if (kindWithTarget) {
      tokens.push({ kind: kindWithTarget as 'NEXT' | 'SUGGEST' | 'SPEAK', target })
    } else if (bareKind) {
      tokens.push({ kind: bareKind as 'DONE' | 'CLOSE' })
    }
    return ''
  }).trim()
  return { content, tokens }
}
```

### Orchestrator routing logic

```ts
// Pseudocode
function handleAgentReply(agentId: string, parsed: ParsedReply, taskCtx: TaskContext) {
  // Surface visible content to webview
  webview.send({ type: 'agent_message', agentId, content: parsed.content })

  // Process tokens in order
  for (const token of parsed.tokens) {
    if (token.kind === 'DONE') {
      finalizeTask(taskCtx, parsed.content)
      return
    }
    if (token.kind === 'NEXT') {
      const target = findAgentInHall(taskCtx.hallId, token.target)
      if (!target) {
        emitBadHandoff(taskCtx, token.target)
        return
      }
      taskCtx.hopCount++
      if (taskCtx.hopCount >= 8) {
        injectConclusionPrompt(target.id, taskCtx)  // forces conclusion
      } else {
        routeMessage(target.id, parsed.content, taskCtx)
      }
      return
    }
    // SUGGEST is council-only; in regular task, ignore (or warn)
    if (token.kind === 'SUGGEST') {
      logger.warn(`SUGGEST token in non-council task; ignoring`)
    }
  }

  // No routing tokens — end task, surface to user
  finalizeTask(taskCtx, parsed.content)
}
```

---

## Skill file format

Skill files (`.hollow-halls/halls/<slug>/skill.md`) are plain Markdown with optional YAML frontmatter:

```markdown
---
name: Development Hall
template: code
created_at: 2026-04-26
---

# Development Hall

You are working in the Development Hall of Hollow Halls. Your purpose is to ship working software.

## What you do

- Read code, understand the architecture
- Propose changes with clear justification
- Implement changes when in Build mode
- Review code when in Review mode
- Hand off to specialist agents in this hall via [NEXT: name]

## What you don't do

- Make business decisions (route to Marketing hall)
- Make visual design decisions (route to Design hall)
- Skip writing tests on consequential changes

## Conventions

- TypeScript, strict mode
- Vitest for unit tests
- Conventional commits

## Examples

When asked to refactor: first explain the plan, then in Build mode execute it.
When asked for a quick fix: identify root cause, fix it, add a regression test.
```

Agent role overlays (`.hollow-halls/halls/<slug>/agents/<name>.md`) are simpler:

```markdown
---
name: Aldric
role: Senior Architect
---

You are Aldric, the senior architect of the Development Hall. You think before you write. You consider edge cases first. You prefer composition over inheritance, simple over clever. When uncertain about a design choice, you propose two alternatives and ask which to pursue.
```

The orchestrator concatenates `skill.md + agents/<name>.md` and passes the result as `--append-system-prompt`.

---

## Tool allowlist values

Each agent's `toolAllowlist` is an array of strings matching Claude Code's tool names. Default categories:

```ts
export const TOOL_CATEGORIES = {
  read:    ['Read', 'Grep', 'Glob', 'WebFetch'],
  write:   ['Edit', 'Write', 'NotebookEdit'],
  bash:    ['Bash'],   // dangerous - confirmation required
  search:  ['WebSearch'],
  task:    ['Task'],   // for delegating to subagents within Claude Code
} as const
```

**Dangerous tools** (require one-time confirmation in agent wizard):
- `Bash` (unless restricted to specific commands like `Bash(npm:*)`)
- `Write` to paths outside the agent's worktree
- Any custom MCP tool flagged dangerous by its manifest
