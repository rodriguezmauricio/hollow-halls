# 04 — Design System

Source of truth for all visual decisions. The mockup at `reference/ui-mockup.html` is the production fidelity reference; this doc is the formal spec.

---

## Aesthetic foundation

Hollow Halls borrows from the visual language of **Hollow Knight**:

- Gothic vector art with hand-illustrated character portraits
- Soul colors (luminous accents in saturated hues against deep dark backgrounds)
- Elegant serif typography for headings
- Minimal ornamental flourishes (corner brackets, ◆ markers, laurel crowns for Heads)
- Pulsing animations on active states (like soul wisps)

This is a **deliberate contrast** to the typical SaaS-flat or terminal-monospace aesthetic. We want it to feel like the inside of an arcane workshop, not an admin dashboard.

---

## Color tokens

### Base palette

```ts
export const colors = {
  bg:       '#080610',  // deepest background
  panel:    '#0d0b1a',  // panel background, slightly raised
  card:     '#111020',  // card surface
  card2:    '#161330',  // card surface (alt, e.g. hover)

  border:   'rgba(255, 255, 255, 0.08)',  // default border
  borderHi: 'rgba(255, 255, 255, 0.16)',  // hover/focus border
  borderUp: 'rgba(255, 255, 255, 0.28)',  // emphasis border

  text:      '#c8c0b0',  // body text
  textDim:   '#5e5a72',  // dim/secondary text
  textHi:    '#f0e8d4',  // headings, emphasized text
  textMid:   '#9a9088',  // mid-emphasis paragraph text

  accent:    '#1d9a7a',  // primary accent (UI affordances, Plan mode dot)
  accent2:   'rgba(29, 154, 122, 0.15)',  // accent fill
} as const
```

### Soul colors (per hall discipline)

Each hall has a single soul color used for borders, glow effects, message accents, and the room's lighting in scenes:

```ts
export const soulColors = {
  oracle:    '#9a4afc',  // The Oracle (purple)
  council:   '#3aaaca',  // Council Chamber (cyan)
  design:    '#3aaa6a',  // Design Hall (green)
  dev:       '#8a62e0',  // Development Hall (violet)
  uiux:      '#3aaaba',  // UI/UX Hall (teal)
  market:    '#d4b040',  // Marketing Hall (amber)
  research:  '#d49040',  // Research Hall (orange)
  cyberSec:  '#dc4a4a',  // Cyber-Sec Hall (red)
} as const
```

Custom halls created by the user can pick any color from the palette via the wizard. The above are defaults.

### Semantic colors

```ts
export const semantic = {
  ok:    '#3aaa6a',
  warn:  '#dca050',
  err:   '#dc4a4a',
  info:  '#3aaaca',
} as const
```

---

## Typography

```ts
export const typography = {
  display: {
    family: '"Cinzel", serif',
    weights: { regular: 400, medium: 500, semibold: 600, bold: 700 },
  },
  body: {
    family: '"IBM Plex Mono", monospace',
    weights: { light: 300, regular: 400, medium: 500 },
  },
  scale: {
    xs:   '11px',
    sm:   '12.5px',
    base: '14px',
    md:   '16px',
    lg:   '18px',
    xl:   '24px',
    xxl:  '32px',
  },
  letterSpacing: {
    tight:   '0',
    normal:  '0.3px',
    wide:    '1.5px',  // for small caps labels
    wider:   '2.5px',  // for headings
    widest:  '4px',    // for hero titles
  },
} as const
```

**Usage rules:**
- Cinzel for: panel titles, hero text, hall names, agent names, mode labels
- IBM Plex Mono for: body text, chat messages, code, descriptions, system labels
- Heading text gets uppercase + wide letter spacing
- Body text stays default case + normal spacing

Load Google Fonts in webview HTML head:
```html
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700&family=IBM+Plex+Mono:wght@300;400;500&display=swap" rel="stylesheet">
```

---

## Spacing scale

```ts
export const space = {
  0: '0',
  1: '4px',
  2: '8px',
  3: '12px',
  4: '16px',
  5: '24px',
  6: '32px',
  7: '48px',
  8: '64px',
  9: '96px',
} as const
```

Use tokens, not raw px. Components built around these multiples will compose harmoniously.

---

## Layout

### Grid

The main dashboard is a CSS Grid layout:

```
┌──────────┬─────────────────────────────────────────────┐
│  side    │  halls panel              │  detail panel   │
│  bar     │  (room cards)             │                 │
│          │                           │                 │
│  200px   ├─────┬───────────────┬─────┴─────────────────┤
│          │ ch  │  bottom chat  │  task panel           │
│          │ an  │               │                       │
│          │ nel │               │  300px                │
│          │ s   │               │                       │
│          │ 220 │               │                       │
└──────────┴─────┴───────────────┴───────────────────────┘
```

Min width: **1500px**. Below that, sections collapse (later concern, not v1).

### Panels

Every panel has:
- Background: `colors.panel`
- Border: 1px solid `colors.border`
- Corner ornaments: 12px L-shapes in opposite corners (top-left, bottom-right)
- Optional Cinzel title with letter-spacing:wider in the panel header

When active/selected, panel border switches to `colors.borderHi` and ornaments brighten.

---

## Iconography

- All icons are **inline SVG**, not icon fonts or emoji
- Stroke-based, 1.5px stroke width, currentColor fill
- 14px / 16px / 18px sizes only
- Lucide-react is the icon source if a stock icon is needed; custom icons authored in Figma → exported as SVG

The ◆ ornament for Heads of Department is a custom diamond glyph (gold-tinted, see `reference/flowmap.html` §V crown SVG).

---

## Character System

Characters are layered SVG compositions. Each character has six slots; a "character config" picks one part for each slot.

### Slots

| Slot | Purpose | Example parts |
|---|---|---|
| `body` | Cloak / robe shape | hk-base (Hollow Knight cloak), tall, broad, slim |
| `clothing` | Overlay on body | apron, vest, armor-plate, scarf |
| `head` | Skull shape | hk-base (default mask), horned, hooded, crowned |
| `eyes` | Eye style | dotted-black (default), glowing, single-cyclops, sparkly |
| `accessory` | Optional add-on | satchel, lantern, scroll, badge |
| `tool` | Held object | quill, hammer, compass, vial, sword |

### Part files

Parts are individual SVG files at `src/characters/parts/<slot>/<id>.svg`. Each part is authored to align to a shared coordinate system: viewBox `0 0 64 96`, with the body centered around (32, 48).

### Compositor

`src/characters/compositor.ts` exposes:

```ts
type CharacterConfig = {
  body: string       // part id
  clothing?: string
  head: string
  eyes: string
  accessory?: string
  tool?: string
  cloakColor: string  // hex (defaults to white, hall-color overlay applied at render time)
}

function renderCharacter(config: CharacterConfig, opts?: {
  size?: number       // px
  showHeadOrnament?: boolean  // ◆ crown for Heads of Department
}): string  // returns SVG markup
```

The compositor stacks the SVG `<g>` elements in order: body → clothing → head → eyes → accessory → tool → ornament (if head). Each part references parameters via SVG variables for color tinting.

### Default character set (v1)

For v1, ship with ~30 parts total spread across slots:

- **6 bodies** (hk-base, tall, broad, slim, hooded, armored)
- **5 clothings** (none, apron, vest, scarf, armor-plate)
- **5 heads** (hk-base, horned, hooded, crowned, masked)
- **4 eyes** (dotted-black, glowing-cyan, single-cyclops, sparkly-gold)
- **5 accessories** (none, satchel, lantern, scroll, badge)
- **5 tools** (none, quill, hammer, compass, vial)

Authoring these is a one-time art effort. Mauricio (15-year graphic designer) authors them in Illustrator, exports as SVG. Each part should be < 2KB optimized.

### Default agent character configs

The 6 default agents (M3 seed data) get hand-picked configs:

```ts
export const defaultAgentCharacters = {
  // Design Hall
  leaf:    { body: 'hk-base', clothing: 'scarf',  head: 'hk-base',  eyes: 'sparkly-gold',  tool: 'quill',   cloakColor: '#3aaa6a' },
  nail:    { body: 'broad',   clothing: 'apron',  head: 'masked',   eyes: 'dotted-black',  tool: 'hammer',  cloakColor: '#3aaa6a' },

  // Development Hall
  shell:   { body: 'tall',    clothing: 'vest',   head: 'horned',   eyes: 'glowing-cyan',  tool: 'compass', cloakColor: '#8a62e0' },
  mire:    { body: 'slim',    head: 'hooded',     eyes: 'dotted-black', accessory: 'scroll', cloakColor: '#8a62e0' },

  // Research Hall
  quill:   { body: 'slim',    clothing: 'scarf',  head: 'hk-base',  eyes: 'sparkly-gold',  tool: 'quill',  accessory: 'satchel', cloakColor: '#d49040' },

  // Marketing Hall (only one default)
  hornet:  { body: 'broad',   clothing: 'armor-plate', head: 'horned', eyes: 'glowing-cyan', tool: 'vial',  cloakColor: '#d4b040' },
}
```

Heads of Department for each hall are marked separately in the agents table (`is_head: true`); the compositor adds the ◆ crown overlay automatically.

---

## Animations

### Pulsing soul indicator

Active halls/agents have a subtle pulse on their status dot:

```css
@keyframes soul-pulse {
  0%, 100% { opacity: 1; }
  50%      { opacity: 0.4; }
}
.status-dot.active {
  animation: soul-pulse 2s ease-in-out infinite;
}
```

Council chamber state pulses faster (1.4s) to differentiate.

### Ornament hover

Corner ornaments brighten on panel hover:

```css
.panel:hover .ornament { border-color: var(--border-hi); }
```

### Streaming text

When an agent is streaming a reply, append a blinking caret at the end:

```css
.streaming::after {
  content: '▍';
  animation: caret 1s steps(2) infinite;
}
@keyframes caret { 50% { opacity: 0; } }
```

### Modal entrances

Wizards (Hall, Agent) fade in with a slight upward translation:

```css
.modal { animation: modal-enter 0.2s ease-out; }
@keyframes modal-enter {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
```

Avoid heavy spring animations or anything that would feel "playful". The aesthetic is solemn.

---

## Theme structure (extensibility)

Themes are the long-term path to v2 ("Ditherpunk", "Cyberpunk neon"). Even in v1, structure the code so a theme is just a tokens module:

```ts
type Theme = {
  colors: typeof colors
  soulColors: typeof soulColors
  semantic: typeof semantic
  typography: typeof typography
  space: typeof space
  // Optional theme-specific assets:
  decorations?: {
    cornerOrnament: ReactComponent
    headOrnament: ReactComponent
    soulPulseDuration: string
  }
}
```

The "Hollow" theme (default v1) lives at `src/webview/theme/themes/hollow.ts`. Future themes go beside it. The theme provider at `src/webview/theme/provider.tsx` lets the user swap themes at runtime via Settings.

For v1, only ship the Hollow theme. Don't waste time on the abstraction layer beyond the basic shape above.
